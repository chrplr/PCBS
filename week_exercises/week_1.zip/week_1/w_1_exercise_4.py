"""
Pascal's triangle

Write a function to compute the first n rows of Pascal's triangle
(see: <https://en.wikipedia.org/wiki/Pascal%27s_triangle>).

For this exercise, you are responsible for testing that your solution yields
correct outputs and handles unexpected inputs gracefully.
You can do it!
"""
