1. If you do not have it yet, install python, e.g. from <https://www.anaconda.com/products/individual>

2. install the python module `expyriment`, following the instructions at <http://docs.expyriment.org/Installation.html>

3. View the file `trials.csv` 

3. Run:

        python cards.py
        
