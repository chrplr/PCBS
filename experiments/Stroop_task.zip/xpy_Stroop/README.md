To prepare the stimuli (if the cards (png files) do not already exist)

    python create_stroop_cards.py
    
To run the experiment:

    python stroop-task.py

Christophe Pallier
